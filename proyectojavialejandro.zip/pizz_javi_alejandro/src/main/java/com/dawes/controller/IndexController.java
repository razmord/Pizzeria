package com.dawes.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dawes.modelo.ProductoVO;
import com.dawes.servicios.ServicioProducto;

@Controller
public class IndexController {
	@Autowired
	ServicioProducto spr;
	@RequestMapping("/index")
	public String lista(Model modelo) {
		modelo.addAttribute("clasica",spr.findAllByFamilia(1));
		modelo.addAttribute("legend",spr.findAllByFamilia(2));
		return "index";
	}
	@RequestMapping("/pizzas")
	public String pizzas(Model modelo) {
		modelo.addAttribute("clasica",spr.findAllByFamilia(1));
		modelo.addAttribute("legend",spr.findAllByFamilia(2));
		return "pizzas";
	}
	@RequestMapping("/bebidas")
	public String bebidas(Model modelo) {
		modelo.addAttribute("bebida",spr.findAllByFamilia(3));
		return "bebidas";
	}
	@RequestMapping("/entrantes")
	public String entrantes(Model modelo) {
		modelo.addAttribute("entrantes",spr.findAllByFamilia(5));
		return "entrantes";
	}
	@RequestMapping("/postres")
	public String postres(Model modelo) {
		modelo.addAttribute("postres",spr.findAllByFamilia(4));
		return "postres";
	}
	@RequestMapping("/ofertas")
	public String ofertas(Model modelo) {
		return "ofertas";
	}
	@RequestMapping("/carrito")
	public String carrito(Model modelo) {
		return "carrito";
	}
	@RequestMapping("/login")
	public String login(Model modelo) {
		return "login";
	}
	@RequestMapping("/addcarro")
	public String addcarro(Model modelo) {
		return "carrito";
	}
}
