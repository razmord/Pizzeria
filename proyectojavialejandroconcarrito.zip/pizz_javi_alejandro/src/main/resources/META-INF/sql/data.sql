insert into producto (nombre,descripcion,familia,precio,imagen) values ("Barbacoa","Pizza Barbacoa",1,7.5,"/pizzas/pizzas/barbacoa.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Buffalo Chicken","Pizza Buffalo Chicken",2,8,"/pizzas/pizzas/buffalochiken.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Cabramelizada","Pizza Cabra Caramelizada",2,8,"./pizzas/pizzas/cabramelizada.jpg");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Carbonara","Pizza Carbonara",1,7.5,"./pizzas/pizzas/carbonara.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Cremozza BBQ","Pizza Cremozza al Estilo BBQ",2,9,"./pizzas/pizzas/cremozza_bbq.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Cremozza Bourbon","Pizza Cremozza al Estilo Bourbon",2,9,"./pizzas/pizzas/cremozza_estilo_bourbon.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Extravaganzza","Pizza Extravaganzza",1,10,"./pizzas/pizzas/extravaganzza.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Kansas","Pizza Kansas",2,7.5,"./pizzas/pizzas/kansaspulledbeef.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Margarita","Pizza Margarita",1,7.5,"./pizzas/pizzas/margarita.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pecado Carnal","Pizza Pecado Carnal",1,7.5,"./pizzas/pizzas/pecado_carnal.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Texas","Pizza Texas al Estilo BBQ",2,8.5,"./pizzas/pizzas/texasbbq.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Duquesa","Pizza duquesa",2,7.5,"./pizzas/pizzas/DUQUESA.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Mediterranea","Pizza Mediterranea",1,7.5,"./pizzas/pizzas/mediterranea.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Peperoni","Pizza Peperoni",1,7.5,"./pizzas/pizzas/peperoni.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("PulledBeef","Pizza PulledBeef",2,8.5,"./pizzas/pizzas/pulledbeef.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pizza por Mitades","Pizza por Mitades",1,8.5,"./pizzas/pizzas/pizza_mitades.png");


insert into producto (nombre,descripcion,familia,precio,imagen) values ("Coca Cola","Lata Coca Cola 33cl",3,1,"./pizzas/bebidas/cocacola.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Fanta Zero Naranja","Lata Fanta Zero Naranja 33cl",3,1,"./pizzas/bebidas/fantazero.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Agua Lanjaron","Botella Agua Lanjaron 50cl",3,1,"./pizzas/bebidas/agua.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pepsi Light","Botella Pepsi Light 50cl",3,1.4,"./pizzas/bebidas/botepepsi.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("London Porter","Lata London Porter 50cl",3,2,"./pizzas/bebidas/cerveza.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Peñon del Aguila","Lata Peñon del Aguila 50cl",3,2,"./pizzas/bebidas/cerveza2.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Estrella Damn","Lata Estrella Damn 33cl",3,1.5,"./pizzas/bebidas/cerveza3.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pepsi","Lata Pepsi 33cl",3,1,"./pizzas/bebidas/latapepsi.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Kas Limón","Lata Kas Limón 33cl",3,0.9,"./pizzas/bebidas/latakaslimon.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Kas Naranja","Lata Kas Naranja 33cl",3,0.9,"./pizzas/bebidas/latakasnaranja.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Mountain Dew","Lata Mountain Dew 50cl",3,1.5,"./pizzas/bebidas/mntdw.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Nestea","Lata Nestea 33cl",3,1,"./pizzas/bebidas/nestea.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("RedBull","Lata Redbull 25",3,2,"./pizzas/bebidas/redbull.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pepsi MAX","Lata Pepsi MAX 33cl",3,0.9,"./pizzas/bebidas/latapepsimax.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pepsi sin cafeina","Lata Pepis sin cafeina 33cl",3,1.5,"./pizzas/bebidas/latapepsisc.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Monster","Lata Monster 50cl",3,1,"./pizzas/bebidas/monster.png");


insert into producto (nombre,descripcion,familia,precio,imagen) values ("Brownie","Brownie de chocolate",4,2.5,"./pizzas/postres/brownie.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Choco Cheese Balls","Muffins rellenos de chocolate",4,3,"./pizzas/postres/chococheeseball.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Cookies","Galletas con pepitas de chocolate",4,1.5,"./pizzas/postres/cookies.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("ChocoEmpanada","Empanada de chocolate",4,3.5,"./pizzas/postres/empanadachoco.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Apple Pie","Empanada de Manzana",4,3.5,"./pizzas/postres/empanadamanzana.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Brownie","Helado sabor Brownie",4,4,"./pizzas/postres/heladobrownie.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Canela","Helado sabor Canela",4,4,"./pizzas/postres/heladocanela.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Cacahuete","Helado sabor Cacahuete",4,4,"./pizzas/postres/heladocacahuete.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Chocolate","Helado sabor Chocolate",4,4,"./pizzas/postres/heladochoco.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Cookie","Helado sabor Cookie",4,4,"./pizzas/postres/heladocookie.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Switch","Helado sabor Galletas y Stracciatella",4,4,"./pizzas/postres/heladoswitch.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Muffin","Magdalena",4,2,"./pizzas/postres/muffing.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Tarta Cherry","Tarta de frutas del bosque con guinda",4,4.5,"./pizzas/postres/tartacherry.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Tarta de Chocolate","Tarta de chocolate",4,4.5,"./pizzas/postres/tartachoco.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado One","Helado sabor Caramelo ",4,4,"./pizzas/postres/heladoone.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Helado Sandwich","Helado sandwich nata",4,4,"./pizzas/postres/heladosandwich.png");


insert into producto (nombre,descripcion,familia,precio,imagen) values ("Alitas","Alitas de pollo",5,5,"./pizzas/entrantes/alitas.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Alitas Salsa","Alitas de pollo con tu salsa favorita",5,5,"./pizzas/entrantes/alitassalsa.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Camembits","Bocados de camembert",5,5,"./pizzas/entrantes/camembits.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Comobo Alitas","Alitas de pollo",5,5,"./pizzas/entrantes/comboalita.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Combo Pollo","Piezas de pollo",5,5,"./pizzas/entrantes/combopollo.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Ensalada de Marisco","Ensalada de marisco",5,5,"./pizzas/entrantes/ensaladamarisco.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Ensalada de Pavo","Ensalada de Pavo",5,5,"./pizzas/entrantes/ensaladapavo.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Kickers","Kickers de pollo",5,4.5,"./pizzas/entrantes/kickers.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pan de Ajo","Pan de Ajo",5,5,"./pizzas/entrantes/pandeajo.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Pan de Ajoqueso","an de Ajo con queso",5,5,"./pizzas/entrantes/pandeajoqueso.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Patatas Grill","Patatas Grill",5,5,"./pizzas/entrantes/patatasgrill.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Salsa Ajo","Salsa Ajo",5,2,"./pizzas/entrantes/salsa-ajo.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Salsa Barbacoa","Salsa Barbacoa",5,5,"./pizzas/entrantes/salsa-barbacoa.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Salsa Ketchup","Salsa Ketchup",5,5,"./pizzas/entrantes/salsa-ketchup.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Salsa Mayo","Salsa Mayo ",5,5,"./pizzas/entrantes/salsa-mayo.png");
insert into producto (nombre,descripcion,familia,precio,imagen) values ("Strippers","Strippers de pollo",5,5,"./pizzas/entrantes/strippers.png");

insert into rol(idrol, nombre) values(1,"USER");
insert into rol(idrol, nombre) values(2,"ADMIN");

insert into usuario(nombre,password,enabled) values("pepe","$2a$10$qwe.rdhx61TNOIEEIbPUoOBSWbwunggHgjHV4xBVcKEWXpA1yddP6", true);
insert into usuario(nombre,password,enabled) values("willyrex","$2a$10$qwe.rdhx61TNOIEEIbPUoOBSWbwunggHgjHV4xBVcKEWXpA1yddP6", true);

