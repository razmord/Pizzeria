package com.dawes.modelo;

import java.util.HashMap;
import java.util.Map;

public class CarritoVO {
	
	private final Map<Integer,LineaCarritoVO> lineaCarrito = new HashMap<Integer,LineaCarritoVO>();

	public CarritoVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Map<Integer,LineaCarritoVO> getLineaCarrito() {
		return lineaCarrito;
	}
	
	private LineaCarritoVO findLineaByCodigo(int code) {
		return lineaCarrito.get(code);
	}
	
	public void addProduct(ProductoVO producto, int cantidad) {
		LineaCarritoVO linea =this.findLineaByCodigo(producto.getIdproducto());
		if(linea==null) {
			linea = new LineaCarritoVO();
			linea.setCantidad(0);
			linea.setProducto(producto);
			this.lineaCarrito.put(producto.getIdproducto(),linea);
		}
		int nuevaCantidad=linea.getCantidad()+cantidad;
		if(nuevaCantidad<=0) {
			this.lineaCarrito.remove(producto.getIdproducto(),linea);
		}else {
			linea.setCantidad(nuevaCantidad);
			this.lineaCarrito.put(producto.getIdproducto(),linea);
		}
		
	}
	   public void validate() {
		   
	    }
	   
	   public void updateProduct(int code, int cantidad) {
		   LineaCarritoVO linea =this.findLineaByCodigo(code);
		   
		   if(linea!=null) {
			   if(cantidad<=0) {
				   this.lineaCarrito.remove(linea);
			   } else {
				   linea.setCantidad(cantidad);
			   }
		   }
	   }
	   public void removeProduct(ProductoVO producto) {
		   LineaCarritoVO linea =this.findLineaByCodigo(producto.getIdproducto());
		   if(linea!=null) {
			   this.lineaCarrito.remove(linea);
		   }
	   }
	   public boolean isEmpty() {
		   return this.lineaCarrito.isEmpty();
	   }
	   public int getCantidadTotal() {
		   final int[] cantidad= {0};
		   lineaCarrito.forEach((k,v) -> cantidad[0] += v.getCantidad());
		   return cantidad[0];
	   }
	   public double getImporteTotal() {
		   final double[] cantidad= {0};
		   lineaCarrito.forEach((k,v) -> cantidad[0] += v.getImporte());
		   return cantidad[0];
	   }
	   public void updateCantidad(CarritoVO cartForm) {
		   if(cartForm!=null) {
			   Map<Integer,LineaCarritoVO> lineas = cartForm.getLineaCarrito();
			   lineas.forEach((k,v) -> this.updateProduct(v.getProducto().getIdproducto(), v.getCantidad()));
		   }
	   }
}
