package com.dawes.modelo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="producto")
public class ProductoVO {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idproducto;
	private String nombre;
	private String descripcion;
	private int familia;

	private float precio;
	private String imagen;
	@OneToMany(mappedBy="producto", fetch=FetchType.LAZY)
	private List<PedidoProductoVO> pedidos;	
	public List<PedidoProductoVO> getPedidos() {
		return pedidos;
	}
	public void setPedidos(List<PedidoProductoVO> pedidos) {
		this.pedidos = pedidos;
	}
	public String getImagen() {
		return imagen;
	}
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	public int getFamilia() {
		return familia;
	}
	public void setFamilia(int familia) {
		this.familia = familia;
	}
	public int getIdproducto() {
		return idproducto;
	}
	public void setIdproducto(int idproducto) {
		this.idproducto = idproducto;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripción() {
		return descripcion;
	}
	public void setDescripción(String descripción) {
		this.descripcion = descripción;
	}
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public ProductoVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductoVO(String nombre, String descripción, int familia, float precio, String imagen,
			List<PedidoProductoVO> pedidos) {
		super();
		this.nombre = nombre;
		this.descripcion = descripción;
		this.familia = familia;
		this.precio = precio;
		this.imagen = imagen;
		this.pedidos = pedidos;
	}
	public ProductoVO(int idproducto, String nombre, String descripción, int familia, float precio, String imagen,
			List<PedidoProductoVO> pedidos) {
		super();
		this.idproducto = idproducto;
		this.nombre = nombre;
		this.descripcion = descripción;
		this.familia = familia;
		this.precio = precio;
		this.imagen = imagen;
		this.pedidos = pedidos;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		result = prime * result + familia;
		result = prime * result + idproducto;
		result = prime * result + ((imagen == null) ? 0 : imagen.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + ((pedidos == null) ? 0 : pedidos.hashCode());
		result = prime * result + Float.floatToIntBits(precio);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductoVO other = (ProductoVO) obj;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (familia != other.familia)
			return false;
		if (idproducto != other.idproducto)
			return false;
		if (imagen == null) {
			if (other.imagen != null)
				return false;
		} else if (!imagen.equals(other.imagen))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (pedidos == null) {
			if (other.pedidos != null)
				return false;
		} else if (!pedidos.equals(other.pedidos))
			return false;
		if (Float.floatToIntBits(precio) != Float.floatToIntBits(other.precio))
			return false;
		return true;
	}
	
	

}
