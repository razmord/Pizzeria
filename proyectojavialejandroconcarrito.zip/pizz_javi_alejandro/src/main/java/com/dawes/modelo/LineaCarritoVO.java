package com.dawes.modelo;

public class LineaCarritoVO {
	private ProductoVO producto;
	private int cantidad;
	
	public LineaCarritoVO() {
		this.cantidad=0;
	}

	public ProductoVO getProducto() {
		return producto;
	}

	public void setProducto(ProductoVO producto) {
		this.producto = producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public double getImporte() {
		return this.producto.getPrecio()*this.cantidad;
	}
}
