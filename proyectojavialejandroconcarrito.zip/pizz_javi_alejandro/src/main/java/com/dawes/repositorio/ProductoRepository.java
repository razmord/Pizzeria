package com.dawes.repositorio;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dawes.modelo.ProductoVO;

@Repository
public interface ProductoRepository extends CrudRepository<ProductoVO, Integer> {
		public List<ProductoVO> findAllByFamilia(int familia);
}
