package com.dawes.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dawes.modelo.RolVO;

@Repository
public interface RolRepository extends JpaRepository<RolVO, Integer> {

	RolVO findByNombre(String nombre);

}
