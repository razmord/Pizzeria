package com.dawes.utils;

public class Rutas {
	
	//carpetas que contienen archivos HTML
	public static final String CARPETA_ALUMNOS = "alumnos/";
	public static final String CARPETA_CURSOS = "cursos/";
}
