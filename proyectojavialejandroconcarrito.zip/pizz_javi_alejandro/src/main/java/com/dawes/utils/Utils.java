package com.dawes.utils;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;

import com.dawes.modelo.CarritoVO;

public class Utils {

	//numeros de elementos por pagina
	public static final int PAGESIZE = 5;
	
	//errores de que se intenten cargar datos de un alumno o de un curso que se ha borrado
	public static final String ERRORALUMNO404 = "redirect:/alumnos?error=No se ha podido realizar la operaci%C3%B3n. Ese alumno ya no existe";
	public static final String ERRORCURSO404 = "redirect:/cursos?error=No se ha podido realizar la operaci%C3%B3n. Ese curso ya no existe";
	
	//comprueba si hay un usuario con la sesion iniciada
	public static boolean isLogged(Authentication authentication) {
		return authentication != null && authentication.isAuthenticated();
	}
	
	//comprueba que una cadena no es ni null ni esta vacia
	public static boolean validarCadena(String cadena) {
		return cadena != null && !cadena.trim().isEmpty();
	}
	 public static CarritoVO getCartInSession(HttpServletRequest request) {
		 
	      CarritoVO CarritoVO = (CarritoVO) request.getSession().getAttribute("myCart");
	 
	    
	      if (CarritoVO == null) {
	         CarritoVO = new CarritoVO();
	          
	         request.getSession().setAttribute("myCart", CarritoVO);
	      }
	 
	      return CarritoVO;
	   }
	 
	   public static void removeCartInSession(HttpServletRequest request) {
	      request.getSession().removeAttribute("myCart");
	   }
	 
	   public static void storeLastOrderedCartInSession(HttpServletRequest request, CarritoVO CarritoVO) {
	      request.getSession().setAttribute("lastOrderedCart", CarritoVO);
	   }
	 
	   public static CarritoVO getLastOrderedCartInSession(HttpServletRequest request) {
	      return (CarritoVO) request.getSession().getAttribute("lastOrderedCart");
	   }
}