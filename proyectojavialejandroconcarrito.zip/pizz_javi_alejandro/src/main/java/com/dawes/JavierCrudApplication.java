package com.dawes;

import javax.persistence.Persistence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class JavierCrudApplication extends SpringBootServletInitializer  {

	public static void main(String[] args) {
		SpringApplication.run(JavierCrudApplication.class, args);
		Persistence.generateSchema("jpa", null);
	}

}

