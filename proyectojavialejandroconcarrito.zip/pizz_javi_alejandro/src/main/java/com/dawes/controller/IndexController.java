package com.dawes.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dawes.modelo.CarritoVO;
import com.dawes.modelo.LineaCarritoVO;
import com.dawes.modelo.PedidoProductoVO;
import com.dawes.modelo.PedidoVO;
import com.dawes.modelo.ProductoVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.servicios.ServicioPedido;
import com.dawes.servicios.ServicioProducto;
import com.dawes.servicios.ServicioUsuario;
import com.dawes.utils.Utils;

@Controller
public class IndexController {
	@Autowired
	ServicioProducto spr;
	@Autowired
	ServicioPedido spe;
	@Autowired
	ServicioUsuario servicioUsuario;
	@Autowired
	BCryptPasswordEncoder pwEncoder;
	
	
	@RequestMapping("/index")
	public String lista(Model modelo) {
		modelo.addAttribute("clasica",spr.findAllByFamilia(1));
		modelo.addAttribute("legend",spr.findAllByFamilia(2));
		return "index";
	}
	@RequestMapping("/pizzas")
	public String pizzas(Model modelo) {
		modelo.addAttribute("clasica",spr.findAllByFamilia(1));
		modelo.addAttribute("legend",spr.findAllByFamilia(2));
		return "pizzas";
	}
	@RequestMapping("/bebidas")
	public String bebidas(Model modelo) {
		modelo.addAttribute("bebida",spr.findAllByFamilia(3));
		return "bebidas";
	}
	@RequestMapping("/entrantes")
	public String entrantes(Model modelo) {
		modelo.addAttribute("entrantes",spr.findAllByFamilia(5));
		return "entrantes";
	}
	@RequestMapping("/postres")
	public String postres(Model modelo) {
		modelo.addAttribute("postres",spr.findAllByFamilia(4));
		return "postres";
	}
	@RequestMapping("/ofertas")
	public String ofertas(Model modelo) {
		return "ofertas";
	}
	@RequestMapping("/carrito")
	public String carrito(Model modelo) {
		return "carrito";
	}
	@RequestMapping("/login")
	public String login(Model modelo) {
		return "login";
	}
	
	@RequestMapping("/addcarro")
	public String addcarro(HttpServletRequest request, Model modelo, //
	         @RequestParam(value = "code", defaultValue = "") String code) {
		ProductoVO product=null;
		if(code!=null&&code.length()>0) {
			product=spr.findById(Integer.parseInt(code)).get();
		}
		if(product!=null) {
			CarritoVO carrito=Utils.getCartInSession(request);
			carrito.addProduct(product, 1);
		}
		return "redirect:/carrito";
	}
	@RequestMapping({"/removecarro"})
	public String removecarro(HttpServletRequest request, Model modelo, //
	         @RequestParam(value = "code", defaultValue = "") String code) {
		ProductoVO product=null;
		if(code!=null&&code.length()>0) {
			product=spr.findById(Integer.parseInt(code)).get();
		}
		if(product!=null) {
			CarritoVO carrito=Utils.getCartInSession(request);
			carrito.removeProduct(product);
		}
		return "redirect:/carrito";
	}
	
	  // POST: Update quantity for product in cart
	   @RequestMapping(value = { "/carrito" }, method = RequestMethod.POST)
	   public String shoppingCartUpdateQty(HttpServletRequest request, //
	         Model model, //
	         @ModelAttribute("cartForm") CarritoVO cartForm) {
	 
		   CarritoVO cartInfo = Utils.getCartInSession(request);
	      cartInfo.updateCantidad(cartForm);;
	 
	      return "redirect:/carrito";
	   }
	   // GET: Show cart.
	   @RequestMapping(value = { "/carrito" }, method = RequestMethod.GET)
	   public String shoppingCartHandler(HttpServletRequest request, Model model) {
	      CarritoVO myCart = Utils.getCartInSession(request);
	 
	      model.addAttribute("cartForm", myCart);
	      return "carrito";
	   }
	   // GET: Show information to confirm.
	   @RequestMapping(value = { "/carritoConfirmation" }, method = RequestMethod.GET)
	   public String shoppingCartConfirmationReview(HttpServletRequest request, Model model) {
	      CarritoVO cartInfo = Utils.getCartInSession(request);
	 
	      if (cartInfo == null || cartInfo.isEmpty()) {
	 
	         return "redirect:/carrito";
	      } 
	      model.addAttribute("cartForm", cartInfo);
	 
	      return "carritoConfirmation";
	   }
	   // POST: Submit Cart (Save)
	   @RequestMapping(value = { "/carritoConfirmation" }, method = RequestMethod.POST)
	 
	   public String shoppingCartConfirmationSave(HttpServletRequest request, Model model) {
	      CarritoVO cartInfo = Utils.getCartInSession(request);
	 
	      if (cartInfo.isEmpty()) {
	 
	         return "redirect:/carrito";
	      } 
	      try {
	    	  SecurityContextHolder.setContext((SecurityContext) request.getSession().getAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY)); 
	    	  String nombre = SecurityContextHolder.getContext().getAuthentication().getName();
	    	  UsuarioVO u = servicioUsuario.findByNombre(nombre);
	    	  PedidoVO p= new PedidoVO();
	    	  p.setUsuario(u);
	    	  List<PedidoProductoVO> productos=new ArrayList<PedidoProductoVO>();
	    	  Map<Integer,LineaCarritoVO> lineaCarrito =cartInfo.getLineaCarrito();
	    	  Iterator<Map.Entry<Integer, LineaCarritoVO>> it =lineaCarrito.entrySet().iterator();
	    	  while (it.hasNext()) {
	    	      Map.Entry<Integer, LineaCarritoVO> pair = it.next();
	    	      productos.add(new PedidoProductoVO(pair.getValue().getCantidad(),p,pair.getValue().getProducto()));
	    	  }
	    	  p.setTotal(cartInfo.getImporteTotal());
	    	  java.util.Date now =new java.util.Date();
	    	  p.setFechaPedido(convertUtilToSql(now));
	    	  p.setProductos(productos);
	    	  spe.save(p);
	      } catch (Exception e) {
	 
	         return "carritoConfirmation";
	      }
	 
	      // Remove Cart from Session.
	      Utils.removeCartInSession(request);
	      Utils.storeLastOrderedCartInSession(request, cartInfo);
	      return "redirect:/index";
	   }
	  
	 
	@RequestMapping(value = "/registro", method = RequestMethod.GET)
	public String registro(Model modelo) {
		modelo.addAttribute("usuario", new UsuarioVO());
		return "registro";
		
	}
    private static java.sql.Date convertUtilToSql(java.util.Date uDate) {
        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
        return sDate;
    }
	@RequestMapping(value = "/registro", method = RequestMethod.POST)
	public String registro(Model modelo, UsuarioVO usuario, HttpServletRequest request) {
		
		usuario.setPassword(pwEncoder.encode(usuario.getPassword()));
		servicioUsuario.save(usuario);
		
		this.autologin(usuario, request);
        modelo.addAttribute("usuario", usuario);
        
		return "redirect:/index";
		
	}
	
	//loguea a un usuario a partir de su usuario y su contraseña
		//este metodo solo es llamado justo despues de que un usuario se registre o edite algo de su perfil, si se hace un login normal lo tratara el propio spring
		public void autologin(UsuarioVO usuario, HttpServletRequest request) {
			
			UserDetails userDetails = servicioUsuario.loadUserByUsername(usuario.getNombre());
			
	        Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, userDetails.getPassword(), userDetails.getAuthorities());
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	        request.getSession().setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, SecurityContextHolder.getContext());
		}

}
