package com.dawes.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.dawes.modelo.RolVO;
import com.dawes.repositorio.RolRepository;

@Service
public class ServicioRolImpl implements ServicioRol {

	@Autowired
	RolRepository ror;

	@Override
	public RolVO findByNombre(String nombre) {
		return ror.findByNombre(nombre);
	}

	@Override
	public <S extends RolVO> S save(S entity) {
		return ror.save(entity);
	}

	@Override
	public <S extends RolVO> Optional<S> findOne(Example<S> example) {
		return ror.findOne(example);
	}

	@Override
	public Page<RolVO> findAll(Pageable pageable) {
		return ror.findAll(pageable);
	}

	@Override
	public List<RolVO> findAll() {
		return ror.findAll();
	}

	@Override
	public List<RolVO> findAll(Sort sort) {
		return ror.findAll(sort);
	}

	@Override
	public Optional<RolVO> findById(Integer id) {
		return ror.findById(id);
	}

	@Override
	public List<RolVO> findAllById(Iterable<Integer> ids) {
		return ror.findAllById(ids);
	}

	@Override
	public <S extends RolVO> List<S> saveAll(Iterable<S> entities) {
		return ror.saveAll(entities);
	}

	@Override
	public boolean existsById(Integer id) {
		return ror.existsById(id);
	}

	@Override
	public void flush() {
		ror.flush();
	}

	@Override
	public <S extends RolVO> S saveAndFlush(S entity) {
		return ror.saveAndFlush(entity);
	}

	@Override
	public void deleteInBatch(Iterable<RolVO> entities) {
		ror.deleteInBatch(entities);
	}

	@Override
	public <S extends RolVO> Page<S> findAll(Example<S> example, Pageable pageable) {
		return ror.findAll(example, pageable);
	}

	@Override
	public long count() {
		return ror.count();
	}

	@Override
	public void deleteAllInBatch() {
		ror.deleteAllInBatch();
	}

	@Override
	public void deleteById(Integer id) {
		ror.deleteById(id);
	}

	@Override
	public RolVO getOne(Integer id) {
		return ror.getOne(id);
	}

	@Override
	public void delete(RolVO entity) {
		ror.delete(entity);
	}

	@Override
	public <S extends RolVO> long count(Example<S> example) {
		return ror.count(example);
	}

	@Override
	public void deleteAll(Iterable<? extends RolVO> entities) {
		ror.deleteAll(entities);
	}

	@Override
	public <S extends RolVO> List<S> findAll(Example<S> example) {
		return ror.findAll(example);
	}

	@Override
	public <S extends RolVO> boolean exists(Example<S> example) {
		return ror.exists(example);
	}

	@Override
	public void deleteAll() {
		ror.deleteAll();
	}

	@Override
	public <S extends RolVO> List<S> findAll(Example<S> example, Sort sort) {
		return ror.findAll(example, sort);
	}
	
	

}
