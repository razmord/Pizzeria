package com.dawes.servicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.dawes.modelo.UsuarioRolVO;
import com.dawes.modelo.UsuarioVO;
import com.dawes.repositorio.UsuarioRepository;

@Service
public class ServicioUsuarioImpl implements UserDetailsService, ServicioUsuario{
	@Autowired
	UsuarioRepository ur;

	@Override
	public UsuarioVO findByNombre(String nombre) {
		return ur.findByNombre(nombre);
	}

	@Override
	public <S extends UsuarioVO> S save(S entity) {
		return ur.save(entity);
	}

	@Override
	public <S extends UsuarioVO> Optional<S> findOne(Example<S> example) {
		return ur.findOne(example);
	}

	@Override
	public Page<UsuarioVO> findAll(Pageable pageable) {
		return ur.findAll(pageable);
	}

	@Override
	public List<UsuarioVO> findAll() {
		return ur.findAll();
	}

	@Override
	public List<UsuarioVO> findAll(Sort sort) {
		return ur.findAll(sort);
	}

	@Override
	public Optional<UsuarioVO> findById(Integer id) {
		return ur.findById(id);
	}

	@Override
	public List<UsuarioVO> findAllById(Iterable<Integer> ids) {
		return ur.findAllById(ids);
	}

	@Override
	public <S extends UsuarioVO> List<S> saveAll(Iterable<S> entities) {
		return ur.saveAll(entities);
	}

	@Override
	public boolean existsById(Integer id) {
		return ur.existsById(id);
	}

	@Override
	public void flush() {
		ur.flush();
	}

	@Override
	public <S extends UsuarioVO> S saveAndFlush(S entity) {
		return ur.saveAndFlush(entity);
	}

	@Override
	public void deleteInBatch(Iterable<UsuarioVO> entities) {
		ur.deleteInBatch(entities);
	}

	@Override
	public <S extends UsuarioVO> Page<S> findAll(Example<S> example, Pageable pageable) {
		return ur.findAll(example, pageable);
	}

	@Override
	public long count() {
		return ur.count();
	}

	@Override
	public void deleteAllInBatch() {
		ur.deleteAllInBatch();
	}

	@Override
	public void deleteById(Integer id) {
		ur.deleteById(id);
	}

	@Override
	public UsuarioVO getOne(Integer id) {
		return ur.getOne(id);
	}

	@Override
	public void delete(UsuarioVO entity) {
		ur.delete(entity);
	}

	@Override
	public <S extends UsuarioVO> long count(Example<S> example) {
		return ur.count(example);
	}

	@Override
	public void deleteAll(Iterable<? extends UsuarioVO> entities) {
		ur.deleteAll(entities);
	}

	@Override
	public <S extends UsuarioVO> List<S> findAll(Example<S> example) {
		return ur.findAll(example);
	}

	@Override
	public <S extends UsuarioVO> boolean exists(Example<S> example) {
		return ur.exists(example);
	}

	@Override
	public void deleteAll() {
		ur.deleteAll();
	}

	@Override
	public <S extends UsuarioVO> List<S> findAll(Example<S> example, Sort sort) {
		return ur.findAll(example, sort);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		System.out.println(username);
UsuarioVO usuario = ur.findByNombre(username);
System.out.println(usuario);
		
		if (usuario != null && usuario.getlUsuarioRol() != null) {
				
			List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
			
			for (UsuarioRolVO usuRol : usuario.getlUsuarioRol()) {
				
				grantList.add(new SimpleGrantedAuthority(usuRol.getRol().getNombre()));
			}
			
			UserDetails user = new User(usuario.getNombre(), usuario.getPassword(), grantList);
			
			return user;
			
		} else {
			throw new UsernameNotFoundException("Error");
		}
	}
	
	
}
